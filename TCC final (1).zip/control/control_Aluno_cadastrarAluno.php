<?php
    include_once "../model/Aluno.php";
    /*
    $aluno->setMatricula('007');
    $aluno->setnome('helio');
    $aluno->setTurma('1'); 
    $aluno->cadastrarAluno();
    exit;
    */
    $data = json_decode(file_get_contents('php://input'), true);

     $nome = $data['nome'];
     $matricula = $data['matricula'];
     $turma = $data['turma'];    

    $aluno = new Aluno();
    
    $aluno->setMatricula($matricula);
    $aluno->setnome($nome);
    $aluno->setTurma($turma);

  
    if($aluno->cadastrarAluno()){
        $json_str = '{"status":"Cadastrado com sucesso"}';
        echo  $json_str;
    }else{
        $json_str = '{"status":"erro"}';
        echo $json_str;
    }
?>