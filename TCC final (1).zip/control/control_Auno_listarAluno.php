<?php

require_once "../model/Aluno.php";
$Aluno = new Aluno();
$resultado = $Aluno->listarAluno();
echo json_encode($resultado);

?>