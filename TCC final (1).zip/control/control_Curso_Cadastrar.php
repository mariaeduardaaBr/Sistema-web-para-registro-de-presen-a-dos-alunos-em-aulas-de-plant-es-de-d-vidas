<?php
require_once "../model/Curso.php";

$data = json_decode(file_get_contents('php://input'), true);
$nomeCurso = $data['nomeCurso'];

$curso = new Curso();
$curso->setnomeCurso($nomeCurso);
if($curso->cadastrarCurso()){
    echo '{"cod":"1","msg":"Cadastrado com sucesso"}';
}else{
    echo '{"cod":"2","msg":"Não Cadastrado"}';
}


?>

