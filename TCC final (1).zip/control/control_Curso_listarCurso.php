<?php
require_once "../model/Curso.php";
$curso = new Curso();
$resultado = $curso->listarCurso();
echo json_encode($resultado );


?>