<?php
require_once "../model/Disciplina.php";

$data = json_decode(file_get_contents('php://input'), true);
$idDisciplina = $data['idDisciplina'];
$nomeDisciplina = $date['txtnomeDisciplina'];
$Turma_idTurma = $date['txtTurma_idTurma'];
$diaSemana = $date['txtdiaSemana'];
$horarioInicio = $date['txthorarioInicio'];
$horarioTermino = $date['txthorarioTermino'];
$Professor_registro = $date['txtProfessor_registro'];

$Disciplina = new Disciplina();

$Turma->setidDisciplina($idDisciplina);
$Disciplina->setnomeDisciplina($nomeDisciplina);
$Disciplina->setTurma_idTurma($Turma_idTurma);
$Disciplina->setdiaSemana($diaSemana);
$Disciplina->sethorarioInicio($horarioInicio);
$Disciplina->sethorarioTermino($horarioTermino);
$Disciplina->setProfessor_registro($Professor_registro);

if($D->cadastrarDisciplina()){
    echo '{"cod":"1","msg":"Cadastrado com sucesso"}';
}else{
    echo '{"cod":"2","msg":"Não Cadastrado"}';
}

?>