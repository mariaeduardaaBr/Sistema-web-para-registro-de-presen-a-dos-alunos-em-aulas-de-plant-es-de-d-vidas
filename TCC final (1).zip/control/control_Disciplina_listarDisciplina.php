<?php
require_once "../model/Disciplina.php";
$Disciplina = new Disciplina();
$resultado = $Disciplina->listarDisciplina();
echo json_encode($resultado );


?>