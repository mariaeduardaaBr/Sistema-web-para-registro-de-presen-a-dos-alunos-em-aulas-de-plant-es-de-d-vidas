<?php

include_once ('../model/Presenca.php');


$dados = json_decode(file_get_contents('php://input'), true);
//echo $data ;

$data = $dados['data'];
$assuntoAbordado = $dados['assuntoAbordado'];
$Aluno_matricula = $dados['Aluno_matricula'];
$aula1 = $dados['aula1'];
$aula2 = $dados['aula2'];


$Presenca = new Presenca();

$Presenca->setDisciplina_idDisciplina($assuntoAbordado);
$Presenca->setdata($data);
$Presenca->setAluno_matricula($Aluno_matricula);
$Presenca->setaula01($aula1);
$Presenca->setaula02($aula2);

if($Presenca->cadastrarPresenca()==true){
    echo '{"cod":"1","msg":"Cadastrado com sucesso"}';
}else{
    echo '{"cod":"2","msg":"Não Cadastrado"}';
}




?>