<?php
require_once "../model/Presenca.php";
$Presenca = new Presenca();
$resultado = $Presenca->listarPresenca();
echo json_encode($resultado );


?>