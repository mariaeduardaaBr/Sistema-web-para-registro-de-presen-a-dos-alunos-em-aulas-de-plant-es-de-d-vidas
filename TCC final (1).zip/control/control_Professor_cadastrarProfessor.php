<?php
require_once "../model/Professor.php";

$data = json_decode(file_get_contents('php://input'), true);
$registro = $data['registro'];
$nome = $data['nome'];
$email = $data['email'];
$dataNascimento = $data['dataNascimento'];
$senha = $data['senha'];


$Professor = new Professor();

$Professor->setRegistro($registro);
$Professor->setnome($nome);
$Professor->setemail($email);
$Professor->setdataNascimento($dataNascimento);
$Professor->setsenha($senha);

if($Professor->cadastrarProfessor()){
    echo '{"cod":"1","msg":"Cadastrado com sucesso"}';
}else{
    echo '{"cod":"2","msg":"Não Cadastrado"}';
}


?>














