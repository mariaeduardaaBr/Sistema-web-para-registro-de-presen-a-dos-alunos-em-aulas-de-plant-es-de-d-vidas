<?php
require_once "../model/Professor.php";
$Professor = new Professor();
$resultado = $Professor->listarProfessor();
echo json_encode($resultado );


?>