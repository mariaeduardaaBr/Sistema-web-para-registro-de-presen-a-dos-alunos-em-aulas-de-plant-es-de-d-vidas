<?php
require_once "../model/Turma.php";

$data = json_decode(file_get_contents('php://input'), true);

$ano = $data['ano'];
$nomeTurma = $data['nomeTurma'];
$idCurso = $data['idCurso'];



$Turma = new Turma();

$Turma->setano($ano);
$Turma->setnomeTurma($nomeTurma);
$Turma->setCurso_idCurso($idCurso);


$resultado = $Turma->cadastrarTurma();

if($resultado==true){

    $arrayResposta["cod"] = "1";
    $arrayResposta["msg"] = "cadastrado com sucesso";
    echo json_encode($arrayResposta);
}else{
    $arrayResposta["cod"] = "2";
    $arrayResposta["msg"] = "Não cadastrado com sucesso";
    echo json_encode($arrayResposta);
}


?>