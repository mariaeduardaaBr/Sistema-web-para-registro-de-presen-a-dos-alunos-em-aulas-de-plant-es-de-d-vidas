<?php
require_once "../model/Turma.php";
$Turma = new Turma();
$resultado = $Turma->listarTurma();
echo json_encode($resultado );



?>