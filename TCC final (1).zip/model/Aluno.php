<?php 
require_once "Banco.php";

class Aluno implements JsonSerializable  {
    private $matricula;
    private $nome;
    private $turma;
    private $curso;
    private $banco;
    private $idTurma;

    public function __construct(){
        $this->banco = new Banco();
    }

    public function jsonSerialize() {
        $array["matricula"] = $this->getMatricula();
        $array["nome"] = $this->getNome();
        $array["turma"] = $this->getTurma();
        $array["idturma"] = $this->getidTurma();
        
        
        return $array;
    }
        
    //public function cadastrarAlunoCSV($dadoCSV){

        function cadastrarAluno(){
            $stmt = $this->banco->getConexao()->prepare("insert into Aluno (matricula, nome, Turma_idTurma) values (?,?,?);");
            $tempMatricula = $this->matricula;
            $tempNome = $this->nome;
            $tempTurma = $this->turma;
            //echo json_encode($this);
            $stmt->bind_param("isi",$tempMatricula,$tempNome,$tempTurma);
            return $stmt->execute();
        }

        public function listarAluno(){
            $stmt = $this->banco->getConexao()->prepare("SELECT * FROM ALUNO join Turma on Turma.idTurma = Turma_idTurma ");
            $stmt->execute();
            $resultado = $stmt->get_result();
            $resultados = array();
            $i = 0;
            while ($linha = $resultado->fetch_object()) {
                $resultados[$i] = new Aluno();
                $resultados[$i]->setMatricula($linha->matricula);
                $resultados[$i]->setNome($linha->nome);
                $resultados[$i]->setTurma($linha->nomeTurma);
                $resultados[$i]->setidTurma($linha->idTurma);
                $i++;
    
            }
            return $resultados;
    
        }

        public function cadastrarAlunoExcel($matricula,$nome,$turma,$ano){
            echo "($matricula,$nome,$turma,$ano)<br>";
            $stmt = $this->banco->getConexao()->prepare("insert into banco.aluno(matricula,nome,Turma_idTurma)value (?,?,(select idTurma from turma where nomeTurma=? and ano=?));");
            $stmt->bind_param("ssss",$matricula,$nome,$turma,$ano);
            return $stmt->execute();
        }

        /*
        public function listarAluno(){
            $stmt = $this->banco->getConexao()->prepare("select * from  Aluno");
            $stmt->execute();
            $resultado = $stmt->get_result();
            $resultados = array();
            $i = 0;
            while ($linha = $resultado->fetch_object()) {
                $resultados[$i] = new Aluno();
                $resultados[$i]->setMatricula($linha->matricula);
                $resultados[$i]->setNome($linha->nome);
                $resultados[$i]->setTurma($linha->Turma);
                $i++;
    
            }
            return $resultados;
    
        }
        */

        public function getCurso(){
                return $this->curso;
        }
        public function setCurso($v){
            $this->curso = $curso;
        }
        public function getMatricula(){
            return $this->matricula;
    
        }
        public function setMatricula($v){
            $this->matricula = $v;
        }
    
        public function getNome(){   
            return $this->nome;
        }
        public function setNome($v){
            $this->nome = $v;
        }
    
        public function getTurma(){
            return $this->turma;
        }
        public function setTurma($v){
            $this->turma = $v;
        }
        public function getidTurma(){
            return $this->idturma;
        }
        public function setidTurma($v){
            $this->idturma = $v;
        }
    
    

    }


?>
