<?php
require_once "Banco.php";
include_once "Banco.php";
include_once "Turma.php";
class Curso implements JsonSerializable{
    private $idCurso;
    private $nomeCurso;
    private $banco;

    public function jsonSerialize() {
        $array["idCurso"] = $this->getIdCurso();
        $array["nomeCurso"] = $this->getNomeCurso();
        
        return $array;
    }

    public function __construct(){
        $this->banco = new Banco();
    }

    public function getIdCurso(){
        return $this->idCurso;
    }
    public function setIdCurso($v){
        $this->idCurso = $v;
    }
    public function getNomeCurso(){
        return $this->nomeCurso;
    }
    public function setNomeCurso($v){
     return $this->nomeCurso = $v;
    }


public function cadastrarCurso(){
        $stmt = $this->banco->getConexao()->prepare("insert into Curso (nomeCurso) values (?);");
        $tempnomeCurso = $this->nomeCurso;

        $stmt->bind_param("s",$tempnomeCurso);
        return $stmt->execute();

}

public function cadastrarCursosVetor($vetorCursos){
     
    foreach($vetorCursos as $curso){
        $this->setNomeCurso($curso);
        $this->cadastrarCurso();
    }

}
    
    public function listarCurso(){
        $stmt = $this->banco->getConexao()->prepare("select * from Curso");
        $stmt->execute();
        $resultado = $stmt->get_result();
        $resultados = array();
        $i = 0;
        while ($linha = $resultado->fetch_object()) {
            $resultados[$i] = new Curso();
            $resultados[$i]->setIdCurso($linha->idCurso);
            $resultados[$i]->setNomeCurso($linha->nomeCurso);
            $i++;

        }
        return $resultados;

    }

}


?>