<?php
require_once "Banco.php";
class Disciplina implements JsonSerializable{
    private $idDisciplina;
    private $nomeDisciplina;
    private $Turma_idTurma;
    private $diaSemana;
    private $horarioInicio;
    private $horarioTermino;
    private $Professor_registro;
    private $banco;
    private $NomeTurma;
    private $Ano;

    public function jsonSerialize() {
        $array["idDisciplina"] = $this->getIdDisciplina();
        $array["nomeDisciplina"] = $this->getNomeDisciplina();
        $array["Turma_idTurma"] = $this->getTurma_idTurma();
        $array["diasemana"] = $this->getDiasemana();
        $array["horarioInicio"] = $this->getHorarioInicio();
        $array["horarioTermino"] = $this->getHorarioInicio();
        $array["NomeTurma"] = $this->getNomeTurma();
        $array["Ano"] = $this->getAno();
        $array["Professor_registro"] = $this->getProfessor_registro();
        
        
        return $array;
    }
    
    public function __construct(){
        $this->banco = new Banco();
    }
        
        public function getIdDisciplina(){
            return $this->idDisciplina;
        }
        public function setIdDisciplina($v){
            $this->idDisciplina = $v;
        }

        public function getNomeDisciplina(){
            return $this->nomeDisciplina;
        }
        public function setNomeDisciplina($v){
            $this->nomeDisciplina = $v;
        }
        
        public function getTurma_idTurma(){
            return $this->Turma_idTurma;
        }
        public function setTurma_idTurma($v){
            $this->Turma_idTurma = $v;
        }

        public function getDiaSemana(){
            return $this->diaSemana;
        }
        public function setDiaSemana($v){
            $this->diaSemana = $v;
        }

        public function getHorarioInicio(){
            return $this->horarioInicio;
        }
        public function setHorarioInicio($v){
            $this->horarioInicio = $v;
        }

        public function getHorarioTermino(){
            return $this->horarioTermino;
        }
        public function setHorarioTermino($v){
            $this->horarioTermino = $v;
        }

        public function getProfessor_registro(){
            return $this->Professor_registro;
        }
        public function setProfessor_registro($v){
            $this->Professor_registro = $v;
        }
        public function getNomeTurma(){
            return $this->NomeTurma;
        }
        public function setNomeTurma($v){
            $this->NomeTurma = $v;
        }
        public function getAno(){
            return $this->Ano;
        }
        public function setAno($v){
            $this->Ano = $v;
        }


        public function cadastrarDisciplina(){
            $stmt = $this->banco->getConexao()->prepare("insert into Disciplina (idDisciplina, nomeDisciplina, Turma_idTurma, diaSemana, horarioInicio, horarioTermino, Professor_registro) values (?,?,?,?,?,?,?);");
            $tempidDisciplina = $this->idDisciplina;
            $tempnomeDisciplina = $this->nomeDisciplina;
            $tempTurma_idTurma = $this->Turma_idTurma;
            $tempdiaSemana = $this->diaSemana;
            $temphorarioInicio = $this->horarioInicio;
            $temphorarioTermino = $this->horarioTermino;
            $tempProfessor_registro = $this->Professor_registro;
            $stmt->bind_param("isiiiii",$tempidDisciplina,$tempnomeDisciplina, $tempTurma_idTurma, $tempdiaSemana, $temphorarioInicio,$temphorarioTermino, $tempProfessor_registro );
            $stmt->execute();
    
    }

    public function listarDisciplina(){
        $stmt = $this->banco->getConexao()->prepare("SELECT * FROM banco.disciplina join banco.turma on  Turma_idTurma = turma.idTurma");
        $stmt->execute();
        $resultado = $stmt->get_result();
        $resultados = array();
        $i = 0;
        while ($linha = $resultado->fetch_object()) {
            $resultados[$i] = new Disciplina();
            $resultados[$i]->setIdDisciplina($linha->idDisciplina);
            $resultados[$i]->setNomeDisciplina($linha->nomeDisciplina);
            $resultados[$i]->setTurma_idTurma($linha->Turma_idTurma);
            $resultados[$i]->setDiaSemana($linha->diaSemana);
            $resultados[$i]->setHorarioInicio($linha->horarioInicio);
            $resultados[$i]->setHorarioTermino($linha->horarioTermino);
            $resultados[$i]->setProfessor_registro($linha->Professor_registro);
            $i++;

        }
        
        return $resultados;

    }

    public function cadastrarDisciplinasExcel(){
        $Professor_registro = $this->getProfessor_registro();
        $nomeDisciplina = $this->getNomeDisciplina();
        $NomeTurma = $this->getNomeTurma();
        $ano = $this->getano();
        echo "($Professor_registro,$nomeDisciplina,$NomeTurma,$ano)<br>";

        $stmt = $this->banco->getConexao()->prepare("insert into banco.Disciplina(Professor_registro,nomeDisciplina,Turma_IdTurma)value (?,?,(select idTurma from banco.turma where NomeTurma =? and ano = ?))");
        
        //echo json_encode($this);
        $stmt->bind_param("ssss",$Professor_registro, $nomeDisciplina,$NomeTurma,$ano);
        return $stmt->execute();
    }

}

        

 





?>