<?php
require_once "Banco.php";

class Presenca  implements JsonSerializable{
    private $idPresenca;
    private $Disciplina_idDisciplina;
    private $data;
    private $assuntoAbordado;
    private $Aluno_matricula;
    private $aula01;
    private $aula02;
    private $banco;
    
    public function jsonSerialize() {
        $array["idPresenca"] = $this->getIdPresenca();
        $array["Disciplina_idDisciplina"] = $this->getDisciplina_idDisciplina();
        $array["data"] = $this->getData();
        $array["assuntoAbordado"] = $this->getAssuntoAbordado();
        $array["Aluno_matricula"] = $this->getAluno_matricula();
        $array["aula01"] = $this->getAula01();
        $array["aula02"] = $this->getAula02();
        
        return $array;
    }
    public function __construct(){
        $this->banco = new Banco();
      
}
    public function getIdPresenca(){
        return $this->idPresenca;
    }
    public function setIdPresenca($v){
        $this->idPresenca = $v;
    }

    public function getDisciplina_idDisciplina(){
        return $this->Disciplina_idDisciplina;
    }
    public function setDisciplina_idDisciplina($v){
        $this->Disciplina_idDisciplina = $v;
    }

    public function getData(){
        return $this->data;
    }
    public function setData($v){
        $this->data = $v;
    }

    public function getAssuntoAbordado(){
        return $this->assuntoAbordado;
    }
    public function setAssuntoAbordado($v){
        $this->assuntoAbordado = $v;
    }

    public function getAluno_matricula(){
        return $this->Aluno_matricula;
    }
    public function setAluno_matricula($v){
        $this->Aluno_matricula = $v;
    }

    public function getAula01(){
        return $this->aula01;
    }
    public function setAula01($v){
        $this->aula01 = $v;
    }

    public function getAula02(){
        return $this->aula02;
    }
    public function setAula02($v){
        $this->aula02 = $v;
    }

    public function cadastrarPresenca(){
        $stmt = $this->banco->getConexao()->prepare("insert into presenca ( Disciplina_idDisciplina, data, Aluno_matricula, aula01, aula02) values (?,?,?,?,?);");
        
        $tempDisciplina_idDisciplina = $this->Disciplina_idDisciplina;
        $tempdata_dia = $this->data;
        //$tempassunto_abordado = $this->assuntoAbordado;
        $tempmatricula_aluno = $this-> Aluno_matricula;
        $tempaula01 = $this->aula01;
        $tempaula02 = $this->aula02;
        $stmt->bind_param("sssss",$tempDisciplina_idDisciplina, $tempdata_dia, $tempmatricula_aluno, $tempaula01, $tempaula02 );
        return $stmt->execute();
    }

    public function listarPresenca(){
        $stmt = $this->banco->getConexao()->prepare("select * from  Presenca");
        $stmt->execute();
        $resultado = $stmt->get_result();
        $resultados = array();
        $i = 0;
        while ($linha = $resultado->fetch_object()) {
            $resultados[$i] = new Presenca();
            $resultados[$i]->setIdPresenca($linha->idPresenca);
            $resultados[$i]->setDisciplina_idDisciplina($linha->Disciplina_idDisciplina);
            $resultados[$i]->setData($linha->data);
            $resultados[$i]->setAssuntoAbordado($linha->assuntoAbordado);
            $resultados[$i]->setAluno_matricula($linha->Aluno_matricula);
            $resultados[$i]->setAula01($linha->aula01);
            $resultados[$i]->setAula02($linha->aula02);
            $i++;

        }
        return $resultados;

    }

}




?>