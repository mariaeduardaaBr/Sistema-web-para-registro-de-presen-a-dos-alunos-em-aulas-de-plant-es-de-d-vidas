<?php
require_once "Banco.php";
class Professor implements JsonSerializable{
    private $registro;
    private $nome;
    private $email;
    private $dataNascimento;
    private $senha;
    private $banco;

    public function jsonSerialize() {
        $array["registro"] = $this->getRegistro();
        $array["nome"] = $this->getNome();
        $array["email"] = $this->getEmail();
        $array["dataNascimento"] = $this->getDataNascimento();
        $array["senha"] = $this->getSenha();
        
        return $array;
    }
            
        public function __construct(){
            $this->banco = new Banco();
        }
    

        public function getRegistro(){
            return $this->registro; 
        }
        public function setRegistro($v){
            $this->registro = $v;
        }
        public function getnome(){
            return $this->nome; 
        }
        public function setnome($v){
            $this->nome = $v;
        }
        public function getEmail(){
            return $this->email;
        }
        public function setEmail($v){
            $this->email = $v;
        }
        public function getDataNascimento(){
            return $this->dataNascimento;
        }
        public function setDataNascimento($v){
            $this->dataNascimento = $v;
        }
        public function getSenha(){
            return $this->senha; 
        }
        public function setSenha($v){
            $this->senha = $v;
        }

        function cadastrarProfessor(){
            $stmt = $this->banco->getConexao()->prepare("insert into Professor (registro, nome, email, dataNascimento, senha) values (?,?,?,?,?);");
            $tempregistro = $this->registro;
            $tempnome = $this->nome;
            $tempemail = $this->email;
            $tempdataNascimento = $this->dataNascimento;
            $tempsenha = $this->senha;
            $stmt->bind_param("sssds",$tempregistro, $tempnome, $tempemail, $tempdataNascimento, $tempsenha);
            return $stmt->execute();
    }

        public function listarProfessor(){
            $stmt = $this->banco->getConexao()->prepare("select * from  Professor");
            $stmt->execute();
            $resultado = $stmt->get_result();
            $resultados = array();
            $i = 0;
            while ($linha = $resultado->fetch_object()) {
                $resultados[$i] = new Professor();
                $resultados[$i]->setRegistro($linha->registro);
                $resultados[$i]->setNome($linha->nome);
                $resultados[$i]->setEmail($linha->email);
                $resultados[$i]->setDataNascimento($linha->dataNascimento);
                $resultados[$i]->setSenha($linha->senha);
                $i++;

            }
            return $resultados;

        }
}


?>
