<?php
require_once "Banco.php";
class Turma implements JsonSerializable{
    private $idTurma;
    private $ano;
    private $nomeTurma;
    private $Curso_idCurso;
    private $nomeCurso;
    
    public function jsonSerialize() {
        $array["idTurma"] = $this->idTurma;
        $array["ano"] = $this->getAno();
        $array["nomeTurma"] = $this->getNomeTurma();
        $array["Curso_idCurso"] = $this->getCurso_idCurso();
        $array["nomeCurso"] = $this->getNomeCurso();

        return $array;
}
    public function __construct(){
        $this->banco = new Banco();
    }
    
    public function setIdTurma($v){
        $this->idTurma=$v;
    }
    public function getIdTurma(){
        return $this->idTurma;
    }
        
        public function getNomeCurso(){
            return $this->nomeCurso;
        }
        public function setNomeCurso($v){
           $this->nomeCurso =$v; 
        }
        public function getAno(){
            return $this->ano;
        } 
        public function setAno($v){
            $this->ano = $v;
        }
        public function getNomeTurma(){
            return $this->nomeTurma; 
        }
        public function setNomeTurma($v){
            $this->nomeTurma = $v;
        }
        public function getCurso_idCurso(){
            return $this->Curso_idCurso;
        }
        public function setCurso_idCurso($v){
            $this->Curso_idCurso = $v;
        }

   
    function cadastrarTurma(){
            $stmt = $this->banco->getConexao()->prepare("insert into Turma (ano, nomeTurma, Curso_idCurso) values (?,?,?);");
            $tempano = $this->ano;
            $tempnomeTurma = $this->nomeTurma;
            $tempCurso_idCurso = $this->Curso_idCurso;
            $stmt->bind_param("isi", $tempano, $tempnomeTurma, $tempCurso_idCurso);
            return $stmt->execute();
    }
    public function cadastrarTurmasCSV(){
        $stmt = $this->banco->getConexao()->prepare("INSERT INTO turma (ano, nomeTurma, Curso_idCurso) VALUES (?, ?, (select idCurso from curso where nomeCurso=?));");
            $tempano = $this->ano;
            $tempnomeTurma = $this->nomeTurma;
            $tempNomeCurso = $this->nomeCurso;
            $stmt->bind_param("iss", $tempano, $tempnomeTurma, $tempNomeCurso);
            return $stmt->execute();
       
    }

    public function listarTurma(){
        $stmt = $this->banco->getConexao()->prepare("select * from  Turma join curso on turma.Curso_idCurso = curso.idCurso");
        $stmt->execute();
        $resultado = $stmt->get_result();
        $resultados = array();
        $i = 0;
        while ($linha = $resultado->fetch_object()) {
            $resultados[$i] = new Turma();
            $resultados[$i]->setIdTurma($linha->idTurma);
            $resultados[$i]->setAno($linha->ano);
            $resultados[$i]->setNomeTurma($linha->nomeTurma);
            $resultados[$i]->setCurso_idCurso($linha->Curso_idCurso);
            $resultados[$i]->setNomeCurso($linha->nomeCurso);
            
            $i++;

        }
        return $resultados;

    }

    
}
?>