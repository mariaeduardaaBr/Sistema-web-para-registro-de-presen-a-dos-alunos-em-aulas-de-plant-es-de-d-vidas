-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';

-- -----------------------------------------------------
-- Schema banco
-- -----------------------------------------------------

-- -----------------------------------------------------
-- Schema banco
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `banco` DEFAULT CHARACTER SET utf8 ;
USE `banco` ;

-- -----------------------------------------------------
-- Table `banco`.`Curso`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `banco`.`Curso` (
  `idCurso` INT NOT NULL AUTO_INCREMENT,
  `nomeCurso` VARCHAR(45) NULL,
  PRIMARY KEY (`idCurso`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `banco`.`Turma`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `banco`.`Turma` (
  `idTurma` INT NOT NULL AUTO_INCREMENT,
  `ano` VARCHAR(45) NULL,
  `nomeTurma` VARCHAR(45) NULL,
  `Curso_idCurso` INT NOT NULL,
  PRIMARY KEY (`idTurma`),
  INDEX `fk_Turma_Curso1_idx` (`Curso_idCurso` ASC),
  CONSTRAINT `fk_Turma_Curso1`
    FOREIGN KEY (`Curso_idCurso`)
    REFERENCES `banco`.`Curso` (`idCurso`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `banco`.`Aluno`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `banco`.`Aluno` (
  `matricula` INT UNSIGNED NOT NULL,
  `nome` VARCHAR(45) NOT NULL,
  `Turma_idTurma` INT NOT NULL,
  PRIMARY KEY (`matricula`),
  UNIQUE INDEX `matricula_UNIQUE` (`matricula` ASC),
  INDEX `fk_Aluno_Turma_idx` (`Turma_idTurma` ASC),
  CONSTRAINT `fk_Aluno_Turma`
    FOREIGN KEY (`Turma_idTurma`)
    REFERENCES `banco`.`Turma` (`idTurma`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `banco`.`Professor`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `banco`.`Professor` (
  `registro` INT NOT NULL,
  `nome` VARCHAR(45) NULL,
  `email` VARCHAR(45) NULL,
  `dataNascimento` VARCHAR(45) NULL,
  `senha` VARCHAR(45) NULL,
  PRIMARY KEY (`registro`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `banco`.`Disciplina`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `banco`.`Disciplina` (
  `idDisciplina` INT NOT NULL AUTO_INCREMENT,
  `nomeDisciplina` VARCHAR(45) NULL,
  `Turma_idTurma` INT NOT NULL,
  `diaSemana` VARCHAR(45) NULL,
  `horarioInicio` TIME NULL,
  `horarioTermino` TIME NULL,
  `Professor_registro` INT NOT NULL,
  PRIMARY KEY (`idDisciplina`),
  INDEX `fk_Disciplina_Turma1_idx` (`Turma_idTurma` ASC),
  INDEX `fk_Disciplina_Professor1_idx` (`Professor_registro` ASC),
  CONSTRAINT `fk_Disciplina_Turma1`
    FOREIGN KEY (`Turma_idTurma`)
    REFERENCES `banco`.`Turma` (`idTurma`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_Disciplina_Professor1`
    FOREIGN KEY (`Professor_registro`)
    REFERENCES `banco`.`Professor` (`registro`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `banco`.`Presenca`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `banco`.`Presenca` (
  `idPresenca` INT NOT NULL AUTO_INCREMENT,
  `Disciplina_idDisciplina` INT NOT NULL,
  `data` DATE NULL,
  `assuntoAbordado` VARCHAR(512) NULL,
  `Aluno_matricula` INT UNSIGNED NOT NULL,
  `aula01` INT NULL,
  `aula02` INT NULL,
  PRIMARY KEY (`idPresenca`),
  INDEX `fk_Presenca_Disciplina1_idx` (`Disciplina_idDisciplina` ASC),
  INDEX `fk_Presenca_Aluno1_idx` (`Aluno_matricula` ASC),
  CONSTRAINT `fk_Presenca_Disciplina1`
    FOREIGN KEY (`Disciplina_idDisciplina`)
    REFERENCES `banco`.`Disciplina` (`idDisciplina`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_Presenca_Aluno1`
    FOREIGN KEY (`Aluno_matricula`)
    REFERENCES `banco`.`Aluno` (`matricula`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
