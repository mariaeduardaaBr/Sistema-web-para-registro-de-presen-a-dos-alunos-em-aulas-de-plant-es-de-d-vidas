<?php

require_once "../model/Curso.php";
require_once "../model/Turma.php";
require_once "../model/Aluno.php";



//salvar o arquivo como .csv (MS DOS)

    // Array com as extensões permitidas
    $extensoes = array('csv');

    // Array com os tipos de erros de upload do PHP
    $erros[0] = 'Não houve erro';
    $erros[1] = 'O arquivo no upload é maior do que o limite do PHP';
    $erros[2] = 'O arquivo ultrapassa o limite de tamanho especifiado no HTML';
    $erros[3] = 'O upload do arquivo foi feito parcialmente';
    $erros[4] = 'Não foi feito o upload do arquivo';

    if ($_FILES['arquivo']['error'] != 0) {
        die("Não foi possível fazer o upload, erro:<br />" .
        $erros[$_FILES['arquivo']['error']]);
        exit; // Para a execução do script
    }

    $extensaoUpload = explode('.', $_FILES['arquivo']['name']);
    //print_r($extensaoUpload);
    $extensao = strtolower($extensaoUpload[sizeof($extensaoUpload)-1]);
    if (array_search($extensao, $extensoes) === false) {
        echo "Por favor, envie arquivos com as seguintes extensões: csv";
        exit;
    }



    ini_set('auto_detect_line_endings',FALSE);

  
    $i=0;
    $row = 1;
    if (($handle = fopen($_FILES['arquivo']['tmp_name'], "r")) !== FALSE) {
        while (($data = fgetcsv($handle, 100000, ",")) !== FALSE) {
            //print_r($data[0]);

            $linha = explode(";",$data[0]); 
            $vetorCursos[$linha[3]]=$linha[3];
        
            
        }
        fclose($handle);

        $curso = new Curso();
        $curso->cadastrarCursosVetor($vetorCursos);
    }


    if (($handle = fopen($_FILES['arquivo']['tmp_name'], "r")) !== FALSE) {
        while (($data = fgetcsv($handle, 100000, ",")) !== FALSE) {
        
            $linha = explode(";",$data[0]);           
            $turma = new Turma();
            $turma->setNomeTurma($linha[2]);
            $turma->setAno($linha[4]);
            $turma->setNomeCurso($linha[3]);
            $turma->cadastrarTurmasCSV();
        }
        fclose($handle);

    }



    if (($handle = fopen($_FILES['arquivo']['tmp_name'], "r")) !== FALSE) {
        while (($data = fgetcsv($handle, 100000, ",")) !== FALSE) {
        
            $linha = explode(";",$data[0]);
            //echo json_encode($data) ;
                     
            $aluno = new Aluno();
            $aluno->cadastrarAlunoExcel($linha[0],$linha[1],$linha[2],$linha[4]);
        }
        fclose($handle);

    }
    exit;

    //faz a leitura de todo o conteúdo do arquivo
    $dados = file_get_contents($_FILES['arquivo']['tmp_name']);
    //divide o conteúdo em um array
    //PHP_EOL significa final da linha.
    //cria uma nova posição no array para cada linha do arquivo
    $linhas = explode(PHP_EOL,$dados);
    //recupera a quantidade de linhas
    $qtdLinhas = count($linhas);

 
    
    $i=0;
    //estrutura de repetição que passa por todas as linhas do vetor de linhas do arquivo
    while($i<$qtdLinhas){
        $linha = $linhas[$i];
        //cria um array onde cada posição do array é definida por ;
        // array[0]; array[1]; array[2]; array[3]; array[4] array[5];
        // IBGE;Estado;UF;Região;Qtd Mun;Sintaxe
        $colunas = explode(';',$linha);
        echo $colunas[0]." - ". $colunas[2]."<br>";
        $i++;
    }
?>