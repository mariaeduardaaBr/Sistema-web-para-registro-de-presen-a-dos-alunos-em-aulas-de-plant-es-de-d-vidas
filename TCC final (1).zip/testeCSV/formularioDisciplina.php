<html>
<head>
<title>Upload de Arquivos com PHP</title>
</head>
<body>
<form method="post" action="controleReceberArquivoDisciplinaCSV.php" enctype="multipart/form-data">
<label>Arquivo:</label>
<input type="file" name="arquivo" /><br>
<input type="submit" value="Enviar" />
</form>
</body>
</html>