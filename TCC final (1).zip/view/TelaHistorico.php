<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Histórico dos alunos - Univap Plantões</title>
    <link rel="icon" type="image/x-icon" href="logounivap.png" />
    <!-- Font Awesome icons (free version)-->
    <script src="https://use.fontawesome.com/releases/v6.3.0/js/all.js" crossorigin="anonymous"></script>
    <!-- Google fonts-->

    <link href="https://fonts.googleapis.com/css?family=Lato:100,100i,300,300i,400,400i,700,700i,900,900i"
        rel="stylesheet" />
    <!-- Core theme CSS (includes Bootstrap)-->
    <link rel="stylesheet" href="TelaDeLogin.css">
    <!-- BOOTSTRAP LINKS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css"
        integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"
        integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo"
        crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"
        integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49"
        crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"
        integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy"
        crossorigin="anonymous"></script>
</head>

<body>
    <nav class="navbar navbar-expand-lg navvbar-white navbar fixed-top">
    <a class="navbar-brand" href="http://localhost:8080/view/TelaLogin.html">  <img src="univapTelalogin.jpg" width="110" height="40" class="d-inline-block align-top" alt=""></a>

        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav"
            aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav">
                <li class="nav-item">
                <a class="nav-link" id="nav-link" href="http://localhost:8080/view/TelaPrincipal.html">Tela de Cadastro</a>
                </li>
                <li class="nav-item">
                <a class="nav-link" id="nav-link" href="http://localhost:8080/view/TelaHistorico.php">Histórico</a>
                </li>
                <li class="nav-item">
                <a class="nav-link" id="nav-link" href="http://localhost:8080/view/TelaAdministrador.html">Administrador</a>
                </li>
                
               
            </ul>
        </div>      
    </nav>
    <br>
    <br>
    <br>
    <br>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
        }

        h1 {
            text-align: center;
        }

        form {
            text-align: center;
            margin-top: 20px;
        }

        label {
            font-weight: bold;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        table,
        th,
        td {
            border: 1px solid #ddd;
            text-align: left;
        }

        th,
        td {
            padding: 8px;

        }

        tr:nth-child(even) {
            background-color: #f2f2f2;
        }
    </style>
                   
                   <div class="container">
                <div class="row justify-content-center">
                    <div class="col-md-6">
                    <center>    
                        <h3>Digite a data: </h3>
                            <form action="" method="POST">
                                <input type="date" id="presenca" name="nomepresenca">
                                <input type="submit" value="Buscar">
                            </form>
                    </center>
                    </div>
                    


            <div class="col-md-6">
                        <center>   
                            <h3>Digite a matrícula: </h3>
                            <form action="" method="POST">
                                <input type="text" id="presenca" name="nomepresenca">
                                <input type="submit" value="Buscar">
                            </form>
                        </center>
                    </div>
                </div>
            </div>

    <div class="resultado">
        <br>
        <br>
        <table>
            <tr>
                <th>Matricula</th>
                <th>Nome do aluno</th>
                <th>Aula 1</th>
                <th>Aula 2</th>
                <th>Data</th>
                <th>Tema abordado</th> 
            </tr>

            
<?php
            if ($_SERVER["REQUEST_METHOD"] == "POST") {
                // Conexão com o banco de dados (substitua com suas informações)
                $servername = "localhost";
                $username = "root";
                $password = "";
                $dbname = "banco";
                $porta = "3307";

                $conn = new mysqli($servername, $username, $password, $dbname, $porta);

                if ($conn->connect_error) {
                    die("Erro na conexão com o banco de dados: " . $conn->connect_error);
                }

                // Recupere o nome do aluno da entrada do formulário
                $presenca = $_POST["nomepresenca"];

                // Consulta SQL para buscar o aluno
                
                $sql = "SELECT Aluno_matricula, aula01, aula02, data, nome, nomeDisciplina
                FROM banco.presenca
                JOIN banco.disciplina ON Disciplina_idDisciplina = Disciplina.idDisciplina
                JOIN banco.aluno ON matricula = Aluno_matricula
                WHERE data LIKE '%$presenca%' OR Aluno_matricula LIKE '%$presenca%'";  
                $result = $conn->query($sql);
               


                    
                if ($result == true) {
                    while ($row = $result->fetch_assoc()) { 
                        
                        if($row['aula01'] == 0){
                            $presenca1 = "F";
                        }else{
                            $presenca1 = "P";
                        }
                        if($row['aula02'] == 0){
                            $presenca2 = "F";
                        }else{
                            $presenca2 = "P";   
                        }

                        $data_formatada = date('d/m/Y', strtotime($row["data"]));

                        echo "<tr>";
                        echo "<td>" . $row["Aluno_matricula"] . "</td>";
                        echo "<td>" . $row["nome"] . "</td>";
                        //echo "<td>" . $row["nomeTurma"] . "</td>";
                        echo "<td>" . $presenca1 . "</td>";
                        echo "<td>" . $presenca2 . "</td>";
                        echo "<td>" . $data_formatada . "</td>";
                        echo "<td>" . $row["nomeDisciplina"] . "</td>";
                        //echo "<tr colspan='3'>";
                        echo "</tr>";
                        
                    }
                } else {
                    //echo "<tr><td colspan='3'>Nenhum aluno encontrado.</td></tr>";
                    echo "Erro:" . mysqli_error($conn);
                }

                $conn->close();
            }


            
?>
        </table>
    </div>
        
</body>
</html>