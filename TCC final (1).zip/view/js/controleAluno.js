carregarComboBox();
const btnCadastrarAluno = document.getElementById("btnCadastrarAluno");
btnCadastrarAluno.onclick = function () {
    const nome = document.getElementById("txtnome").value;
    const matricula = document.getElementById("txtMatricula").value;
    const turma = document.getElementById("txtturma").value;
    if (nome == "") {
        alert("");
        return;
    }
    const json = {
        nome: nome,
        matricula: matricula,
        turma: turma,
    }
    console.log(json)


    fetch('../control/control_Aluno_cadastrarAluno.php',
        {
            method: "POST",
            body: JSON.stringify(json)
        })
        .then((response) => {
            //console.log(response);
            return response.json();
            //return response;
        })
        .then((data) => {
            console.log("data:"+JSON.stringify(data))
     
        // similar behavior as clicking on a link
        window.location.href = "";

        });


}
function carregarComboBox(){
    fetch('../control/control_Turma_listarTurma.php',
        {
            method: "GET",
        })
        .then((response) => {
            //console.log(response);
            return response.json();
            //return response;
        })
        .then((data) => {
            //console.log("data:"+JSON.stringify(data))
            
         
            var select =  document.getElementById("txtturma");
            data.forEach(function(dado, index) {
                console.log(dado.idTurma);
                   
                var option = document.createElement( 'option' );
            
                option.value = dado.idTurma;
                option.text = dado.nomeTurma + " - "+ dado.nomeCurso;
                select.add(option);
                });
           /*
            for(var turma in objjson) {
                console.log(turma);
            
            }
            */

            //

        });
}
    