//carregarComboBox();
const btn = document.getElementById("btnCadastrar");
btn.onclick = function () {
    const nomeCurso = document.getElementById("txtnomeCurso").value;
    if (nomeCurso == "") {
        alert("");
        return;
    }
    const json = {
        nomeCurso: nomeCurso,
    }
    console.log(json)
    fetch('../control/control_Curso_cadastrar.php',
        {
            method: "POST",
            body: JSON.stringify(json)
        })
        .then((response) => {
            //console.log(response);
            return response.json();
            //return response;
        })
        .then((data) => {
            console.log("data:"+JSON.stringify(data))
            const div = document.getElementById("divResposta");
            div.innerHTML = data.msg;    

        });
    }
function carregarComboTurmas(){
    fetch('../control/control_Curso_listarCurso.php',
        {
            method: "GET",
        })
        .then((response) => {
            //console.log(response);
            return response.json();
            //return response;
        })
        .then((data) => {
            //console.log("data:"+JSON.stringify(data))
            
         
            var select =  document.getElementById("txtCurso");
            data.forEach(function(dado, index) {
                console.log(dado.idCurso);
                   
                var option = document.createElement( 'option' );
            
                option.value = dado.idCurso;
                option.text = dado.nomeCurso;
                select.add(option);
                });
           /*
            for(var turma in objjson) {
                console.log(turma);
            
            }
            */

            //

        });
}

