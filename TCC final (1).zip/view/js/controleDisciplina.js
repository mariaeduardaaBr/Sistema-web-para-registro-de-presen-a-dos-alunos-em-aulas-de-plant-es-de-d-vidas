carregarComboBoxTurmas();
const btnCadatrarDisciplina = document.getElementById("btnCadatrarDisciplina");
btnCadatrarDisciplina.onclick = function () {

    const nomeDisciplina = document.getElementById("txtnomeDisciplina").value;
    const Turma_idTurma = document.getElementById("txtnomeDisciplina").value;
    const diaSemana = document.getElementById("txtnomeDisciplina").value;
    const horarioInicio = document.getElementById("txthorarioInicio").value;
    const horarioTermino = document.getElementById("txthorarioTermino").value;
    const Professor_registro = document.getElementById("txtProfessor_registro").value;

    if (nomeCurso == "") {
        alert("");
        return;
    }
    const json = {
        idCurso: idCurso,
        nomeCurso: nomeCurso,
    }
    console.log(json)
    fetch('../control/control_Curso_cadastrar.php',
        {
            method: "POST",
            body: JSON.stringify(json)
        })
        .then((response) => {
            //console.log(response);
            return response.json();
            //return response;
        })
        .then((data) => {
            console.log("data:"+JSON.stringify(data))


        });
    }

    function abrirAlerta(){
        alert("seja bem vindo")
    }


    function carregarComboBoxTurmas(){
        fetch('../control/control_Turma_listarTurma.php',
            {
                method: "GET",
            })
            .then((response) => {
                //console.log(response);
                return response.json();
                //return response;
            })
            .then((data) => {
                //console.log("data:"+JSON.stringify(data))
                
             
                var select =  document.getElementById("cboTurmas");
                data.forEach(function(dado, index) {
                    console.log(dado.idTurma);
                       
                    var option = document.createElement( 'option' );
                
                    option.value = dado.idTurma;
                    option.text = dado.nomeTurma + " - "+ dado.nomeCurso;
                    select.add(option);
                    });
               /*
                for(var turma in objjson) {
                    console.log(turma);
                
                }
                */
    
                //
    
            });
    }



