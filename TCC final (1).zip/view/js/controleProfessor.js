carregarComboBoxProf();
const btnCadastrarProfessor = document.getElementById("btnCadastrarProfessor");
btnCadastrarProfessor.onclick = function () {
    const registro = document.getElementById("txtregistro").value;
    const nome = document.getElementById("txtnome").value;
    const email = document.getElementById("txtemail").value;
    const dataNascimento = document.getElementById("txtdataNascimento").value;
    const senha = document.getElementById("txtsenha").value;
    if (registro == "") {
        alert("");
        return;
    }
    const json = {
        registro: registro,
        nome: nome,
        email: email,
        dataNascimento: dataNascimento,
        senha: senha,
    }
    console.log(json)


    fetch('../control/control_Profesor_cadastrarProfessor.php',
        {
            method: "POST",
            body: JSON.stringify(json)
        })
        .then((response) => {
            //console.log(response);
            return response.json();
            //return response;
        })
        .then((data) => {
            console.log("data:"+JSON.stringify(data))


        });


}