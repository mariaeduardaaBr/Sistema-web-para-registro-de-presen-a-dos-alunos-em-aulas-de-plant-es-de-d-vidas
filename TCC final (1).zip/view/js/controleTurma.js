carregarComboBoxCursos();
const btnCadastrarTurma = document.getElementById("btnCadastrarTurma");
btnCadastrarTurma.onclick = function () {
    const ano = document.getElementById("txtano").value;
    const nomeTurma = document.getElementById("txtnomeTurma").value;
    const idCurso = document.getElementById("cboCursos").value;
    
    cadastrarTurma(ano,nomeTurma,idCurso);

}

function cadastrarTurma(ano,nomeTurma,idCurso){
   
    const json = {
        ano: ano,
        nomeTurma: nomeTurma,
        idCurso: idCurso,
        
    }
    console.log(json)


    fetch('../control/control_Turma_Cadastrar.php',
        {
            method: "POST",
            body: JSON.stringify(json)
        })
        .then((response) => {
            console.log(response);
            return response.json();
            //return response;
        })
        .then((data) => {
            console.log("data:"+JSON.stringify(data))


        });
}
function carregarComboBoxCursos(){
    console.log("carregarComboBox()")
    fetch('/control/control_Curso_listarCurso.php',
        {
            method: "GET",
        })
        .then((response) => {
            //console.log(response);
            console.log("fetch ../control/control_Turma_listarTurma.php")
            return response.json();
            //return response;
        })
        .then((data) => {
            console.log("data:"+JSON.stringify(data))
            
         
            var select =  document.getElementById("cboCursos");
            data.forEach(function(dado, index) {
                console.log(dado.idTurma);
                   
                var option = document.createElement( 'option' );
            
                option.value = dado.idCurso;
                option.text = dado.nomeCurso;
                select.add(option);
                });
           /*
            for(var turma in objjson) {
                console.log(turma);
            
            }
            */

            //

        });
}