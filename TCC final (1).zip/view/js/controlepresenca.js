carregarComboBox();
const btn = document.getElementById("btnCadastrar");
btn.onclick = function () {
    const idPresenca = document.getElementById("txtidPresenca").value;
    const Disciplina_idDisciplina = document.getElementById("txtDisciplina_idDisciplina").value;
    const data = document.getElementById("txtdata").value;
    const assuntoAbordadoa = document.getElementById("txtassuntoAbordado").value;
    const Aluno_matricula = document.getElementById("txtAluno_matricula").value;
    const aula01 = document.getElementById("txtaula01").value;
    const aula02 = document.getElementById("txtaula02").value;
    if (idPresenca == "") {
        alert("");
        return;
    }
    const json = {
        idPresenca: idPresenca,
        Disciplina_idDisciplina: Disciplina_idDisciplina,
        data: data,
        assuntoAbordadoa: assuntoAbordadoa,
        Aluno_matricula: Aluno_matricula,
        aula01: aula01,
        aula02: aula02,
    }
    console.log(json)


    fetch('../control/control_Presenca_cadastrar.php',
        {
            method: "POST",
            body: JSON.stringify(json)
        })
        .then((response) => {
            //console.log(response);
            return response.json();
            //return response;
        })
        .then((data) => {
            console.log("data:"+JSON.stringify(data))


        });


}
function carregarComboBox(){
    fetch('../control/control_Turma_listarTurma.php',
        {
            method: "GET",
        })
        .then((response) => {
            //console.log(response);
            return response.json();
            //return response;
        })
        .then((data) => {
            //console.log("data:"+JSON.stringify(data))
            
         
            var select =  document.getElementById("txtturma");
            data.forEach(function(dado, index) {
                console.log(dado.idTurma);
                   
                var option = document.createElement( 'option' );
            
                option.value = dado.idTurma;
                option.text = dado.nomeTurma;
                select.add(option);
                });
           /*
            for(var turma in objjson) {
                console.log(turma);
            
            }
            */

            //

        });
}